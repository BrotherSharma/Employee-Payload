using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2nd_Exam.Models
{
    public class tblemp
    {
        public int c_id {get; set;}
        public string c_name {get; set;}
        public DateTime c_date{get; set;}
        public int c_salary{get; set;}
        public string c_gender{ get; set;}
    }
}