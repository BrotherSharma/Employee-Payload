using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using _2nd_Exam.Models;
using _2nd_Exam.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace _2nd_Exam.Controllers
{
    //[Route("[controller]")]
    public class EmpController : Controller
    {
        private readonly ILogger<EmpController> _logger;
        private readonly IEmpRepository _repo;

        public EmpController(ILogger<EmpController> logger, IEmpRepository repo)
        {
            _logger = logger;
            _repo = repo;
        }

        public IActionResult Index()
        {
            var emp = _repo.GetAll();
            return View(emp);
        }
        [HttpGet]
        public IActionResult Insert()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Insert(tblemp emp)
        {
            _repo.Insert(emp);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Update(int id)
        {
            var emp =_repo.GetOne(id);
            return View(emp);
        }
        [HttpPost]
        public IActionResult Update(tblemp emp)
        {
            _repo.Update(emp);
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id)
        {
            _repo.Delete(id);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Payroll(int id)
        {
            var emp =_repo.GetOne(id);
            return View(emp);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}