using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _2nd_Exam.Models;

namespace _2nd_Exam.Repository
{
    public interface IEmpRepository
    {
        public List<tblemp> GetAll();
        public void Insert(tblemp emp);
        public tblemp GetOne(int id);
        public void Update(tblemp emp);
        public void Delete(int id);
    }
}