using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using _2nd_Exam.Models;
using Npgsql;

namespace _2nd_Exam.Repository
{
    public class EmpRepository : IEmpRepository
    {
        public NpgsqlConnection _conn;
        public EmpRepository(NpgsqlConnection conn)
        {
            _conn = conn;
        }
        public List<tblemp> GetAll()
        {
            var emp = new List<tblemp>();
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT * FROM t_emp;",_conn);
            command.CommandType = CommandType.Text;
            var reader = command.ExecuteReader();
            while(reader.Read())
            {
                var tblemp = new tblemp();
                {
                    tblemp.c_id = Convert.ToInt32(reader["c_id"]);
                    tblemp.c_name = reader["c_name"].ToString();
                    tblemp.c_salary= Convert.ToInt32(reader["c_salary"]);
                    tblemp.c_date = Convert.ToDateTime(reader["c_date"]);
                    tblemp.c_gender = reader["c_gender"].ToString();
                
                }
                emp.Add(tblemp);
            }
            _conn.Close();
            return emp;
        }
        public tblemp GetOne(int id)
        {
            var emp = new tblemp();
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT * FROM t_emp WHERE c_id = @id;",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@id",id);
            var reader = command.ExecuteReader();
            while(reader.Read())
            {
               
                    emp.c_id = Convert.ToInt32(reader["c_id"]);
                    emp.c_name = reader["c_name"].ToString();
                    emp.c_salary= Convert.ToInt32(reader["c_salary"]);
                    emp.c_date = Convert.ToDateTime(reader["c_date"]);
                    emp.c_gender = reader["c_gender"].ToString();
                
                
                
            }
            _conn.Close();
            return emp;
        }
        public void Insert(tblemp emp)
        {
            _conn.Open();
            using var command = new NpgsqlCommand("INSERT INTO t_emp (c_name, c_gender, c_salary, c_date) VALUES (@c_name, @c_gender, @c_salary, @c_date)",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_name",emp.c_name);
            command.Parameters.AddWithValue("@c_gender",emp.c_gender);
            command.Parameters.AddWithValue("@c_salary",emp.c_salary);
            command.Parameters.AddWithValue("@c_date",emp.c_date);
            command.ExecuteNonQuery();
            _conn.Close();
        }
        public void Update(tblemp emp)
        {
            _conn.Open();
            using var command = new NpgsqlCommand("UPDATE t_emp SET c_name= @c_name, c_gender= @c_gender, c_salary= @c_salary,c_date= @c_date WHERE c_id=@id",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@id",emp.c_id);
            command.Parameters.AddWithValue("@c_name",emp.c_name);
            command.Parameters.AddWithValue("@c_gender",emp.c_gender);
            command.Parameters.AddWithValue("@c_salary",emp.c_salary);
            command.Parameters.AddWithValue("@c_date",emp.c_date);
            command.ExecuteNonQuery();
            _conn.Close();

        }
        public void Delete(int id)
        {
            _conn.Open();
            using var command = new NpgsqlCommand("DELETE FROM t_emp WHERE c_id = @id",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@id",id);
            command.ExecuteNonQuery();
            _conn.Close();
        }
        
    }
}